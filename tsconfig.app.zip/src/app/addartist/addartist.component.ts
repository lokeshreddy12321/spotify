import { Component, OnInit } from '@angular/core';
import { Artist } from '../artist';
import { ArtistService } from '../artist.service';

@Component({
  selector: 'app-addartist',
  templateUrl: './addartist.component.html',
  styleUrls: ['./addartist.component.css']
})
export class AddartistComponent implements OnInit {
artists:Artist
result : any;
  constructor(private _artistservice:ArtistService) {
    this.artists=new Artist();
   }
   addartist()
   {
    alert("added successfully");
    this._artistservice.addartist(this.artists).subscribe(x=>{
      this.result=x;
    });
   }

  ngOnInit(): void {
  }

}
