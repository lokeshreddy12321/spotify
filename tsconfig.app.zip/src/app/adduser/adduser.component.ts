import { Component, OnInit } from '@angular/core';
import { Users } from '../users';
import { UsersService } from '../users.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
users:Users
result :any;


  constructor(private _router : Router,private _usersservice:UsersService) {
    this.users=new Users()
   }
   adduser()
   {
    alert("added successfully");
   
    this._usersservice.adduser(this.users).subscribe(x=>{
      this.result=x;
      this._router.navigate(['/'])
    })
   }
   

  ngOnInit(): void {
  }

}
