export class Songs {
    public songname : string;
    public dateofrelease : Date;
    
    constructor(){}
}
