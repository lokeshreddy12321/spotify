export class Users {
    public name :string;
    public email :string;
    public password : string;
    constructor(){}
}
