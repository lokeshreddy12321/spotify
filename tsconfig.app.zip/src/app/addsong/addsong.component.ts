import { Component, OnInit } from '@angular/core';
import { Songs } from '../songs';
import { SongsService } from '../songs.service';

@Component({
  selector: 'app-addsong',
  templateUrl: './addsong.component.html',
  styleUrls: ['./addsong.component.css']
})
export class AddsongComponent implements OnInit {
songs : Songs
result :any;
  constructor(private _songsservice : SongsService) {
    this.songs = new Songs()
   }
   addsong()
   {
    alert("added successfully");
    this._songsservice.addsong(this.songs).subscribe(x=>{
      this.result=x;
    })
   }

  ngOnInit(): void {
  }

}
