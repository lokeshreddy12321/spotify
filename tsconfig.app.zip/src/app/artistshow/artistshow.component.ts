import { Component, OnInit } from '@angular/core';
import { Artist } from '../artist';
import { ArtistService } from '../artist.service';
@Component({
  selector: 'app-artistshow',
  templateUrl: './artistshow.component.html',
  styleUrls: ['./artistshow.component.css']
})
export class ArtistshowComponent implements OnInit {
arts : Artist[];
  constructor(private _artistservice:ArtistService) { 
    this._artistservice.artistshow().subscribe(x=>{
      this.arts=x;
    })
  }

  ngOnInit(): void {
  }

}
