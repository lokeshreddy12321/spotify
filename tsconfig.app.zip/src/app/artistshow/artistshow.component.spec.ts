import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtistshowComponent } from './artistshow.component';

describe('ArtistshowComponent', () => {
  let component: ArtistshowComponent;
  let fixture: ComponentFixture<ArtistshowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArtistshowComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ArtistshowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
