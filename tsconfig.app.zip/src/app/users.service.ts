import { Injectable } from '@angular/core';
import { Users } from './users';
import { UserloginComponent } from './userlogin/userlogin.component';
import { first, Observable } from 'rxjs';
import {HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class UsersService {
  validatesong(user : string , pwd :string): Observable<string>
  {
return this._http.get<string>("https://localhost:44345/api/users/"+user+"/"+pwd)
  }
  adduser(user:Users)
  {
    return this._http.post("https://localhost:44345/api/user/adduser",user);
  }

  constructor(private _http : HttpClient) { }
}
