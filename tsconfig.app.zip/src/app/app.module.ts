import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ArtistshowComponent } from './artistshow/artistshow.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { SongshowComponent } from './songshow/songshow.component';
import { FormsModule } from '@angular/forms';
import { AddartistComponent } from './addartist/addartist.component';
import { AddsongComponent } from './addsong/addsong.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LogindashboardComponent } from './logindashboard/logindashboard.component';
import { AdduserComponent } from './adduser/adduser.component';
import { RouterModule, Routes } from '@angular/router';
const appRoutes : Routes = [
  {path:'',component:HomepageComponent},
  {path:'adduser',component:AdduserComponent},
    
    
  
  {path:'userlogin',component:UserloginComponent},
  
    
  {path:'logindashboard',component:LogindashboardComponent},
  {path:'logindashboard',component:LogindashboardComponent,children:[
    {path:'songsshow',component:SongshowComponent,outlet:'mphasis'},
    {path:'addsong',component:AddsongComponent,outlet:'mphasis'},
    {path:'artistshow',component:ArtistshowComponent,outlet:'mphasis'},
    {path:'addartist',component:AddartistComponent,outlet:'mphasis'},
   
  
  ]},
]
@NgModule({
  declarations: [
    AppComponent,
    ArtistshowComponent,
    UserloginComponent,
    SongshowComponent,
    AddartistComponent,
    AddsongComponent,
    HomepageComponent,
    LogindashboardComponent,
    AdduserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
