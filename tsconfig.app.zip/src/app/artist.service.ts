import { Injectable } from '@angular/core';
import { first, Observable } from 'rxjs';
import {HttpClient } from '@angular/common/http';
import { Artist } from './artist';
@Injectable({
  providedIn: 'root'
})
export class ArtistService {
  artistshow() : Observable<Artist[]>
  {
    return this._http.get<[Artist]>("https://localhost:44345/api/artists")
  }
addartist(artists:Artist)
{
  return this._http.post("https://localhost:44345/api/artists/addartist",artists);

}
  constructor(private _http : HttpClient) { }
}
