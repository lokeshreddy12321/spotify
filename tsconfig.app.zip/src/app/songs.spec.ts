import { Songs } from './songs';

describe('Songs', () => {
  it('should create an instance', () => {
    expect(new Songs()).toBeTruthy();
  });
});
