import { Component, OnInit } from '@angular/core';
import { Users } from '../users';
import { UsersService } from '../users.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
email : string;
password : string
result : string;
login(){
  this._usersservice.validatesong(this.email,this.password).subscribe(x=>{
    if (x=="1"){
      localStorage.setItem("user",this.email);
      this._router.navigate(["/logindashboard"])
    }
  })
}
  constructor(private _router : Router,private _usersservice: UsersService) { }

  ngOnInit(): void {
  }

}
