import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SongshowComponent } from './songshow.component';

describe('SongshowComponent', () => {
  let component: SongshowComponent;
  let fixture: ComponentFixture<SongshowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SongshowComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SongshowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
