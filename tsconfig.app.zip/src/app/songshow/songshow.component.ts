import { Component, OnInit } from '@angular/core';
import { Songs } from '../songs';
import { SongsService } from '../songs.service';

@Component({
  selector: 'app-songshow',
  templateUrl: './songshow.component.html',
  styleUrls: ['./songshow.component.css']
})
export class SongshowComponent implements OnInit {
song : Songs[]
  constructor(private _songsservice:SongsService) {
    this._songsservice.songsshow().subscribe(x=>{
      this.song=x;
    })
   }

  ngOnInit(): void {
  }

}
