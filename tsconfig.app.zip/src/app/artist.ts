export class Artist {
    public name : string;
    public dateofbirth : Date;
    public bio : string;
    constructor(){}
}
