import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Songs } from './songs';

import {HttpClient } from '@angular/common/http';

import { SongshowComponent } from './songshow/songshow.component';
@Injectable({
  providedIn: 'root'
})
export class SongsService {
  songsshow() : Observable<Songs[]>
  {
    return this._http.get<[Songs]>("https://localhost:44345/api/songs");
  }

addsong(songs:Songs)
{
  return this._http.post("https://localhost:44345/api/song/addsong",songs);
}
  constructor(private _http : HttpClient) { }
}
